g++ -O3 -std=c++11 -I../lib -I/PATH_TO_BOOST/include -L/PATH_TO_BOOST/lib harmonize.cpp -lboost_serialization -o harmonize
