#include "../lib/serialization_dataform_classes.hpp"
#include "../lib/debug.hpp"
#include "../lib/picojson.h"

using namespace std;

class Evaluator{
public:
    int Z;
    int N;
    int NMAX;
    double likelihood;
    double max_likelihood;
    double prev_split_like;
    double prev_merge_like;
    int prev_opr;
    int argmax_T;
    vector<int> chord_groundtruth;
    vector<vector<int> > x;
    vector<vector<int> > x_onset;
    vector<int> chord;
    vector<int> chord_onset;
    vector<int> leaf;
    vector<int> leafpa;
    picojson::value tree;
    vector<vector<vector<double> > > trans;
    vector<vector<double> > out;
    vector<vector<double> > emit;
    vector<vector <double> > pitch_first;
    vector<vector<vector <double> > > pitch_trans;
    vector<vector <double> > chord_onset_trans;
    int split_count;
    int split_accept;
    int split_tree_up;
    int split_rhythm_up;
    int split_melody_up;
    int merge_count;
    int merge_accept;
    int merge_tree_up;
    int merge_rhythm_up;
    int merge_melody_up;
    int rhythm_count;
    int rhythm_accept;
    int rhythm_like_up;
    Evaluator(int _Z){
        Z = _Z;
    }

    int input_melody(const std::string& fname)
    {
        std::ifstream ifs(fname);
        if (!ifs.good()) {
            std::cout << "failed to open a melody file" << std::endl;
            std::exit(EXIT_FAILURE);
        }

        std::vector<int> pitches;
        std::vector<int> onsets;
        {
            int x;
            std::string line;
            {// load onsets
                std::getline(ifs, line);
                std::stringstream ss(line);
                while (ss >> x) { onsets.push_back(x); }
            }
            {// load pitches
                std::getline(ifs, line);
                std::stringstream ss(line);
                while (ss >> x) { pitches.push_back(x); }
            }
        }
        ifs.close();

        assert(pitches.size() == onsets.size());

        for (int i = 0; i < pitches.size(); i++) {
            const int p = pitches[i];
            const int o = onsets[i];
            const int m = o / 16;  // Measure
            if (x.size() <= m) {
                x.push_back(std::vector<int>());
                x_onset.push_back(std::vector<int>());
            }
            x[m].push_back(p);
            x_onset[m].push_back(o);
        }

        return x.size();
    }

    void input_params(string paramdir, int Z, string tryy, string cycle)
    {
        {
            string fname = paramdir + "/../params_rock_corpus_nometrical.dat";
            ifstream ifs(fname);
            if (!ifs.good()) {
              cerr << "In loading params of rock corpus: failed to open a file" << endl;
              exit(EXIT_FAILURE);
            }

            RockCorpusParams rcparams;
            boost::archive::xml_iarchive ia(ifs);
            ia >> boost::serialization::make_nvp("Data",rcparams);
            ifs.close();

            rcparams.log_convert();
            rcparams.alpha_product_to_pitch_models(2.0);

            pitch_first = rcparams.pitch_class_first;
            pitch_trans = rcparams.pitch_class_trans;
            chord_onset_trans = rcparams.chord_onset_pr;
        }
        {
            string fname = paramdir + "/Z" + std::to_string(Z) + "/" + tryy + "/" + cycle + ".txt";
            ifstream ifs(fname.c_str());
            if (!ifs.good()) {
              cerr << "In loading params of PCFG: failed to open '" << fname << "'" << endl;
              exit(EXIT_FAILURE);
            }

            PcfgParams pcfg(Z);
            boost::archive::xml_iarchive ia(ifs);
            ia >> boost::serialization::make_nvp("Data",pcfg);
            ifs.close();

            pcfg.log_convert();

            trans = pcfg.trans;
            out = pcfg.out;
            emit = pcfg.emit;
        }
    }

    void init_chord(){
        for(int i=0;i<N;i++){
            chord_onset[i] = NOTE_RESOLUTION*i;
        }
        vector<vector<double> > melodyout(N, vector<double>(K));
        for(int c=0;c<K;c++){
            melodyout[0][c] = pitch_first[c][x[0][0]%12]+melodylike(c,x[0]);
        }
        for(int i=1;i<N;i++){
            for(int c=0;c<K;c++){
                melodyout[i][c] = pitch_trans[c][x[i-1][x[i-1].size()-1]%12][x[i][0]%12]+melodylike(c,x[i]);
            }
        }
        for(int i=0;i<N;i++){
            double max = -(numeric_limits<double>::max());
            int argmaxc = 0;
            for(int c=0;c<K;c++){
                double a = melodyout[i][c];
                if(a > max){
                    max = a;
                    argmaxc = c;
                }
            }
            chord[i] = argmaxc;
        }
    }
    void resample_chord_symbols(
        picojson::value &best_tree,
        int T,
        vector<State> &best,
        vector<double> &oppr,
        vector<vector<vector<double> > > &beta,
        vector<vector<vector<double> > > &cbeta)
    {
        //calculate inside probability
        for(int A=0;A<Z;A++){
            double sum = -(numeric_limits<double>::max());
            for(int c=0;c<K;c++){
                cbeta[A][0][c] = out[A][c]+(pitch_first[c][x[0][0]%12]+melodylike(c,x[0]));
                sum = log_sum(sum,cbeta[A][0][c]);
            }
            beta[A][0][0] = emit[A][1]+sum;
            for(int i=1;i<N;i++){
                double sum = -(numeric_limits<double>::max());
                for(int c=0;c<K;c++){
                    cbeta[A][i][c] = out[A][c]+(pitch_trans[c][x[i-1][x[i-1].size()-1]%12][x[i][0]%12]+melodylike(c,x[i]));
                    sum = log_sum(sum,cbeta[A][i][c]);
                }
                beta[A][i][i] = emit[A][1]+sum;
            }
        }
        for(int n=1;n<N;n++){
            for(int i=0;i<N-n;i++){
                for(int A=0;A<Z;A++){
                    double sum = -(numeric_limits<double>::max());
                    for(int B=0;B<Z;B++){
                        for(int C=0;C<Z;C++){
                            for(int j=1;j<n+1;j++){
                                sum = log_sum(sum,trans[A][B][C]+beta[B][i][i+j-1]+beta[C][i+j][i+n]);
                            }
                        }
                    }
                    beta[A][i][i+n] = emit[A][0]+sum;
                }
            }
        }
        for(int i=0;i<N;i++){
            leafpa[i] = -1;
        }
        double like_tree = 0;
        string json_cand;
        outside_sampling(json_cand,0,0,N-1,beta,cbeta,like_tree);
        stringstream ss;
        ss << json_cand;
        ss >> tree;

        likelihood = like_tree;
        likelihood += pitch_first[chord[0]][x[0][0]%12]+melodylike(chord[0],x[0]);
        for(int i=1;i<N;i++){
            likelihood += pitch_trans[chord[i]][x[i-1][x[i-1].size()-1]%12][x[i][0]%12];
            likelihood += melodylike(chord[i],x[i]);
            likelihood += two_onset_to_chord_onset_trans(chord_onset[i-1],chord_onset[i]);
        }
        likelihood += two_onset_to_chord_onset_trans(chord_onset[N-1],8*NOTE_RESOLUTION);

        refine_5best(best);
        if(likelihood > max_likelihood){
            best_tree = tree;
            max_likelihood = likelihood;
            argmax_T = T;
        }
        prev_opr = 0;
        oppr[0] = 0.0;
        oppr[2] = 0.1;
        oppr[3] = 0.1;
    }
    void outside_sampling(
        string &json,
        int A, int i, int n,
        vector<vector<vector<double> > > &beta,
        vector<vector<vector<double> > > &cbeta,
        double &like_tree)
    {
        if(n==0){
            int c = discrete_sampling_log(cbeta[A][i]);
            chord[i] = c;
            leaf[i] = A;
            like_tree += emit[A][1]+out[A][c];
            stringstream ss;
            ss << i;
            json += ss.str();
        }else{
            vector<vector<vector<double> > > p(Z, vector<vector<double> >(Z, vector<double>(n)));
            double ch = 0.0;
            for(int B=0;B<Z;B++){
                for(int C=0;C<Z;C++){
                    for(int j=0;j<n;j++){
                        p[B][C][j] = exp(emit[A][0]+trans[A][B][C]+beta[B][i][i+j]+beta[C][i+j+1][i+n]-beta[A][i][i+n]);
                        ch += p[B][C][j];
                    }
                }
            }
            assert(abs(ch-1.0)<0.0001);

            vector<int> next = discrete_sampling_3d(p);
            int B = next[0];
            int C = next[1];
            int j = next[2];

            stringstream bb,cc;
            bb << B, cc << C;

            if(n==1){
                leafpa[i] = A;
            }
            like_tree += emit[A][0]+trans[A][B][C];
            json += "{\"ntl\":"+bb.str()+",\"left\":";
            outside_sampling(json,B,i,j,beta,cbeta,like_tree);
            json += ",\"ntr\":"+cc.str()+",\"right\":";
            outside_sampling(json,C,i+j+1,n-j-1,beta,cbeta,like_tree);
            json += "}";
        }
    }
    void optimize_chord_symbols(
        picojson::value &best_tree,
        int T,
        vector<State> &best,
        vector<double> &oppr,
        vector<vector<vector<double> > > &delta,
        vector<vector<vector<int> > > &argmax_B,
        vector<vector<vector<int> > > &argmax_C,
        vector<vector<vector<int> > > &argmax_j,
        vector<vector<int> > &argmax_c)
    {
        //calculate max inside probability
        for(int A=0;A<Z;A++){
            double max = -(numeric_limits<double>::max());
            int argmax = 0;
            for(int c=0;c<K;c++){
                double temp = out[A][c]+(pitch_first[c][x[0][0]%12]+melodylike(c,x[0]));///x[0].size();
                if(temp > max){
                    max = temp;
                    argmax = c;
                }
            }
            delta[A][0][0] = emit[A][1]+max;
            argmax_c[A][0] = argmax;
            for(int i=1;i<N;i++){
                double max = -(numeric_limits<double>::max());
                int argmax = 0;
                for(int c=0;c<K;c++){
                    double temp = out[A][c]+(pitch_trans[c][x[i-1][x[i-1].size()-1]%12][x[i][0]%12]+melodylike(c,x[i]));///x[i].size();
                    if(temp > max){
                        max = temp;
                        argmax = c;
                    }
                }
                delta[A][i][i] = emit[A][1]+max;
                argmax_c[A][i] = argmax;
            }
        }
        for(int n=1;n<N;n++){
            for(int i=0;i<N-n;i++){
                for(int A=0;A<Z;A++){
                    double max = -(numeric_limits<double>::max());
                    for(int B=0;B<Z;B++){
                        for(int C=0;C<Z;C++){
                            for(int j=1;j<n+1;j++){
                                double temp = emit[A][0]+trans[A][B][C]+delta[B][i][i+j-1]+delta[C][i+j][i+n];
                                if(temp > max){
                                    max = temp;
                                    argmax_B[A][i][i+n] = B;
                                    argmax_C[A][i][i+n] = C;
                                    argmax_j[A][i][i+n] = j;
                                }
                            }
                        }
                    }
                    delta[A][i][i+n] = max;
                }
            }
        }
        for(int i=0;i<N;i++){
            leafpa[i] = -1;
        }
        double like_tree = 0;
        string json_cand;
        back_track_tree(json_cand,0,0,N-1,argmax_B,argmax_C,argmax_j,argmax_c,like_tree);
        stringstream ss;
        ss << json_cand;
        ss >> tree;

        likelihood = like_tree;
        likelihood += pitch_first[chord[0]][x[0][0]%12]+melodylike(chord[0],x[0]);
        for(int i=1;i<N;i++){
            likelihood += pitch_trans[chord[i]][x[i-1][x[i-1].size()-1]%12][x[i][0]%12];
            likelihood += melodylike(chord[i],x[i]);
            likelihood += two_onset_to_chord_onset_trans(chord_onset[i-1],chord_onset[i]);
        }
        likelihood += two_onset_to_chord_onset_trans(chord_onset[N-1],NOTE_RESOLUTION*8);

        refine_5best(best);
        if(likelihood > max_likelihood){
            best_tree = tree;
            max_likelihood = likelihood;
            argmax_T = T;
        }
        /*if(prev_opr==2){
            if(likelihood >= prev_split_like){
                cout << T << " :splitting:accepted -> likelihood raise." << endl;
            }else{
                cout << T << " :splitting:accepted -> NO!!!!!!!!!!!!!!!" << endl;
            }
        }
        if(prev_opr==3){
            if(likelihood >= prev_merge_like){
                cout << T << " :merging:accepted -> likelihood raise." << endl;
            }else{
                cout << T << " :merging:accepted -> NO!!!!!!!!!!!!!!!" << endl;
            }
        }*/
        prev_opr = 0;
        oppr[0] = 0.0;
        oppr[2] = 0.1;
        oppr[3] = 0.1;
    }
    void back_track_tree(
        string &json,
        int pa, int start, int end,
        vector<vector<vector<int> > > &argmax_B,
        vector<vector<vector<int> > > &argmax_C,
        vector<vector<vector<int> > > &argmax_j,
        vector<vector<int> > &argmax_c,
        double &like_tree)
    {
        if(start==end){
            int n = argmax_c[pa][start];
            string chordname;
            if(n==24){
                chordname = "other";
            }else if(n==25){
                chordname = "NC";
            }else{
                chordname = num_to_tone(n/2)+num_to_color(n%2);
            }
            /*cout << "\tS" << start << end << " [label=" << pa << "]" << endl;
            cout << "\tS" << start << end << n << " [label=\"" << chordname << "\"]" << endl;
            cout << "\tS" << start << end << " -> S" << start << end << n << " [label=\"" << exp(out[pa][n]) << "\"]" << endl;
            cout << "\tS" << start << end << " -> S[color=white]" << endl;
            cout << "\tS" << start << end << n << " -> S[color=white]" << endl;*/
            chord[start] = n;
            leaf[start] = pa;
            like_tree += emit[pa][1]+out[pa][n];
            stringstream ss;
            ss << start;
            json += ss.str();
        }else{
            int B = argmax_B[pa][start][end];
            int C = argmax_C[pa][start][end];
            int pivot = start + argmax_j[pa][start][end];

            /*cout << "\tS" << start << end << " [label=" << pa << "]" << endl;
            cout << "\tS" << start << pivot-1 << " [label=" << B << "]" << endl;
            cout << "\tS" << pivot << end << " [label=" << C << "]" << endl;
            cout << "\tS" << start << end << " -> S" << start << pivot-1 << " [label=\"" << exp(trans[pa][B][C]) << "\"]" << endl;
            cout << "\tS" << start << end << " -> S" << pivot << end << endl;*/

            stringstream bb,cc;
            bb << B, cc << C;

            if(start+1==end and start==pivot-1){
                leafpa[start] = pa;
            }
            like_tree += emit[pa][0]+trans[pa][B][C];
            json += "{\"ntl\":"+bb.str()+",\"left\":";
            back_track_tree(json,B,start,pivot-1,argmax_B,argmax_C,argmax_j,argmax_c,like_tree);
            json += ",\"ntr\":"+cc.str()+",\"right\":";
            back_track_tree(json,C,pivot,end,argmax_B,argmax_C,argmax_j,argmax_c,like_tree);
            json += "}";
        }
    }
    void resample_chord_rhythms(
        picojson::value &best_tree,
        int T,
        vector<State> &best,
        vector<double> &oppr,
        vector<vector<vector<double> > > &delta,
        vector<vector<vector<int> > > &argmax_B,
        vector<vector<vector<int> > > &argmax_C,
        vector<vector<vector<int> > > &argmax_j,
        vector<vector<int> > &argmax_c)
    {
        if(N==1){
            return;
        }

        //make proposal of chord & melody
        State proposal;
        proposal.x = x;
        proposal.x_onset = x_onset;
        proposal.chord = chord;
        proposal.chord_onset = chord_onset;

        int n = uniform_rand_int(0,N-2);

        //resampling chord_onset[n+1]
        //cout << "start:" << x_onset[n][0] << ", end:" << x_onset[n+1][x[n+1].size()-1] << endl;
        proposal.chord_onset[n+1] = uniform_rand_int(x_onset[n][0]+1,x_onset[n+1][x[n+1].size()-1]);

        int i=0;
        while(true){
            if(i<x[n].size()){
                if(x_onset[n][i] >= proposal.chord_onset[n+1]){
                    proposal.x[n].resize(i);
                    proposal.x_onset[n].resize(i);
                    proposal.x[n+1].insert(proposal.x[n+1].begin(),x[n].begin()+i,x[n].end());
                    proposal.x_onset[n+1].insert(proposal.x_onset[n+1].begin(),x_onset[n].begin()+i,x_onset[n].end());
                    break;
                }
            }else{
                if(x_onset[n+1][i-x[n].size()] >= proposal.chord_onset[n+1] or x[n+1].size()==i-x[n].size()){
                    proposal.x[n].insert(proposal.x[n].end(),x[n+1].begin(),x[n+1].begin()+i-x[n].size());
                    proposal.x_onset[n].insert(proposal.x_onset[n].end(),x_onset[n+1].begin(),x_onset[n+1].begin()+i-x_onset[n].size());
                    proposal.x[n+1].erase(proposal.x[n+1].begin(),proposal.x[n+1].begin()+i-x[n].size());
                    proposal.x_onset[n+1].erase(proposal.x_onset[n+1].begin(),proposal.x_onset[n+1].begin()+i-x_onset[n].size());
                    break;
                }
            }
            i++;
        }
        /*for(int i=0;i<x.size();i++){
            for(int j=0;j<x[i].size();j++){
                cout << x[i][j] << " ";
            }
            cout << endl;
        }
        cout << "->" << endl;
        proposal.print_x();*/

        //p(s)
        double current_like;
        double melody_current;
        if(n==0){
            melody_current = pitch_first[chord[n]][x[n][0]%12];
        }else{
            melody_current = pitch_trans[chord[n]][x[n-1][x[n-1].size()-1]%12][x[n][0]%12];
        }
        melody_current += melodylike(chord[n],x[n]);
        melody_current += pitch_trans[chord[n+1]][x[n][x[n].size()-1]%12][x[n+1][0]%12];
        melody_current += melodylike(chord[n+1],x[n+1]);
        current_like = melody_current;
        double rhythm_current = two_onset_to_chord_onset_trans(chord_onset[n],chord_onset[n+1]);
        if(n==N-2){
            rhythm_current += two_onset_to_chord_onset_trans(chord_onset[n+1],8*NOTE_RESOLUTION);
        }else{
            rhythm_current += two_onset_to_chord_onset_trans(chord_onset[n+1],chord_onset[n+2]);
        }
        current_like += rhythm_current;

        //p(s*)
        double proposal_like;
        double melody_proposal;
        if(n==0){
            melody_proposal = pitch_first[chord[n]][proposal.x[n][0]%12];
        }else{
            melody_proposal = pitch_trans[chord[n]][proposal.x[n-1][proposal.x[n-1].size()-1]%12][proposal.x[n][0]%12];
        }
        melody_proposal += melodylike(chord[n],proposal.x[n]);
        melody_proposal += pitch_trans[chord[n+1]][proposal.x[n][proposal.x[n].size()-1]%12][proposal.x[n+1][0]%12];
        melody_proposal += melodylike(chord[n+1],proposal.x[n+1]);
        proposal_like = melody_proposal;
        double rhythm_proposal = two_onset_to_chord_onset_trans(proposal.chord_onset[n],proposal.chord_onset[n+1]);
        if(n==N-2){
            rhythm_proposal += two_onset_to_chord_onset_trans(proposal.chord_onset[n+1],8*NOTE_RESOLUTION);
        }else{
            rhythm_proposal += two_onset_to_chord_onset_trans(proposal.chord_onset[n+1],proposal.chord_onset[n+2]);
        }
        proposal_like += rhythm_proposal;

        if(proposal_like > current_like){
            rhythm_like_up += 1;
        }

        double acceptance = min(1.0,exp(proposal_like-current_like));
        if(mh_accept(acceptance)){
            x = proposal.x;
            x_onset = proposal.x_onset;
            chord_onset = proposal.chord_onset;
            likelihood += proposal_like - current_like;
            rhythm_accept += 1;
            prev_opr = 1;
            oppr[0] = 0.4;
        }
        refine_5best(best);
        if(likelihood > max_likelihood){
            best_tree = tree;
            max_likelihood = likelihood;
            argmax_T = T;
        }
    }
    void split_a_chord(
        picojson::value &best_tree,
        int T,
        vector<State> &best,
        vector<double> &oppr,
        vector<vector<vector<double> > > &delta,
        vector<vector<vector<int> > > &argmax_B,
        vector<vector<vector<int> > > &argmax_C,
        vector<vector<vector<int> > > &argmax_j,
        vector<vector<int> > &argmax_c)
    {
        State proposal;
        proposal.x = x;
        proposal.x_onset = x_onset;
        proposal.chord = chord;
        proposal.chord_onset = chord_onset;
        proposal.leaf = leaf;
        proposal.leafpa = leafpa;

        vector<double> p(N);
        int sum = 0.0;
        for(int i=0;i<N;i++){
            if(x[i].size()>1){
                p[i] = 1.0;
                sum += 1.0;
            }
        }
        p = normalize(p);
        int n = discrete_sampling(p);
        double model_trans = log(1.0/(double)sum);

        sum = 0;
        for(int i=0;i<N;i++){
            if(leafpa[i]>-1){
                sum += 1;
            }
        }
        double model_rev_trans = log(1.0/(double)sum);
        model_rev_trans += out[leaf[n]][chord[n]];

        vector<int> sample_two_node(2);
        vector<vector<double> > two_node_pr(Z, vector<double>(Z));

        for(int B=0;B<Z;B++){
            for(int C=0;C<Z;C++){
                two_node_pr[B][C] = trans[leaf[n]][B][C];
            }
        }
        sample_two_node = discrete_sampling_2d_log(two_node_pr);
        proposal.leafpa[n] = leaf[n];
        proposal.leafpa.insert(proposal.leafpa.begin()+n+1,-1);
        proposal.leaf[n] = sample_two_node[0];
        proposal.leaf.insert(proposal.leaf.begin()+n+1,sample_two_node[1]);

        proposal.chord[n] = discrete_sampling_log(out[proposal.leaf[n]]);
        proposal.chord.insert(proposal.chord.begin()+n+1,discrete_sampling_log(out[proposal.leaf[n+1]]));
        model_trans += trans[proposal.leafpa[n]][proposal.leaf[n]][proposal.leaf[n+1]];
        model_trans += out[proposal.leaf[n]][proposal.chord[n]];
        model_trans += out[proposal.leaf[n+1]][proposal.chord[n+1]];

        //chord_onset[n+1]
        //cout << x_onset[n][0] << "<" << x_onset[n][x[n].size()-1] << endl;
        proposal.chord_onset.insert(proposal.chord_onset.begin()+n+1,uniform_rand_int(x_onset[n][0]+1,x_onset[n][x[n].size()-1]));
        model_trans += log(1.0/(x_onset[n][x[n].size()-1]-x_onset[n][0]));

        int i=0;
        while(true){
            if(x_onset[n][i] >= proposal.chord_onset[n+1]){
                break;
            }
            i++;
        }
        vector<int> null;
        proposal.x.insert(proposal.x.begin()+n+1,null);
        proposal.x_onset.insert(proposal.x_onset.begin()+n+1,null);
        proposal.x[n+1].insert(proposal.x[n+1].begin(),x[n].begin()+i,x[n].end());
        proposal.x_onset[n+1].insert(proposal.x_onset[n+1].begin(),x_onset[n].begin()+i,x_onset[n].end());

        proposal.x[n].resize(i);
        proposal.x_onset[n].resize(i);

        /*for(int i=0;i<x.size();i++){
            for(int j=0;j<x[i].size();j++){
                cout << x[i][j] << " ";
            }
            cout << endl;
        }
        cout << "->" << endl;
        proposal.print_x();*/

        //p(s)
        double current_like = emit[leaf[n]][1]+out[leaf[n]][chord[n]];
        double melody_current;
        if(n==0){
            melody_current = pitch_first[chord[n]][x[n][0]%12];
        }else{
            melody_current = pitch_trans[chord[n]][x[n-1][x[n-1].size()-1]%12][x[n][0]%12];
        }
        melody_current += melodylike(chord[n],x[n]);
        current_like += melody_current;
        double rhythm_current;
        if(n==N-1){
            rhythm_current = two_onset_to_chord_onset_trans(chord_onset[n],8*NOTE_RESOLUTION);
        }else{
            rhythm_current = two_onset_to_chord_onset_trans(chord_onset[n],chord_onset[n+1]);
        }
        current_like += rhythm_current;

        //p(s*)
        double proposal_like = emit[proposal.leafpa[n]][0]+trans[proposal.leafpa[n]][proposal.leaf[n]][proposal.leaf[n+1]];
        proposal_like += emit[proposal.leaf[n]][1]+out[proposal.leaf[n]][proposal.chord[n]];
        proposal_like += emit[proposal.leaf[n+1]][1]+out[proposal.leaf[n+1]][proposal.chord[n+1]];
        double melody_proposal;
        if(n==0){
            melody_proposal = pitch_first[proposal.chord[n]][proposal.x[n][0]%12];
        }else{
            melody_proposal = pitch_trans[proposal.chord[n]][proposal.x[n-1][proposal.x[n-1].size()-1]%12][proposal.x[n][0]%12];
        }
        melody_proposal += melodylike(proposal.chord[n],proposal.x[n]);
        melody_proposal += pitch_trans[proposal.chord[n+1]][proposal.x[n][proposal.x[n].size()-1]%12][proposal.x[n+1][0]%12];
        melody_proposal += melodylike(proposal.chord[n+1],proposal.x[n+1]);
        proposal_like += melody_proposal;
        double rhythm_proposal = two_onset_to_chord_onset_trans(proposal.chord_onset[n],proposal.chord_onset[n+1]);
        if(n==N-1){
            rhythm_proposal += two_onset_to_chord_onset_trans(proposal.chord_onset[n+1],8*NOTE_RESOLUTION);
        }else{
            rhythm_proposal += two_onset_to_chord_onset_trans(proposal.chord_onset[n+1],proposal.chord_onset[n+2]);
        }
        proposal_like += rhythm_proposal;

        if(rhythm_proposal > rhythm_current){
            split_rhythm_up += 1;
        }
        if(melody_proposal > melody_current){
            split_melody_up += 1;
        }
        if(emit[leaf[n]][1]+out[leaf[n]][chord[n]] <
            emit[proposal.leafpa[n]][0]+trans[proposal.leafpa[n]][proposal.leaf[n]][proposal.leaf[n+1]]
            +emit[proposal.leaf[n]][1]+out[proposal.leaf[n]][proposal.chord[n]]
            +emit[proposal.leaf[n+1]][1]+out[proposal.leaf[n+1]][proposal.chord[n+1]]){
            split_tree_up += 1;
        }
        double acceptance = min(1.0,exp(proposal_like+model_rev_trans-current_like-model_trans));
        if(mh_accept(acceptance)){
            likelihood += proposal_like - current_like;
            prev_split_like = likelihood;
            x = proposal.x;
            x_onset = proposal.x_onset;
            chord = proposal.chord;
            chord_onset = proposal.chord_onset;
            leaf = proposal.leaf;
            leafpa = proposal.leafpa;
            N++;
            split_accept+=1;
            prev_opr = 2;
            oppr[0] = 0.4;
            convert_json(n,"split");
        }
        refine_5best(best);
        if(likelihood > max_likelihood){
            best_tree = tree;
            max_likelihood = likelihood;
            argmax_T = T;
        }
        assert(N <= NMAX);
    }
    void merge_two_chords(
        picojson::value &best_tree,
        int T,
        vector<State> &best,
        vector<double> &oppr,
        vector<vector<vector<double> > > &delta,
        vector<vector<vector<int> > > &argmax_B,
        vector<vector<vector<int> > > &argmax_C,
        vector<vector<vector<int> > > &argmax_j,
        vector<vector<int> > &argmax_c)
    {

        if(chord.size()<=2){
            return;
        }
        State proposal;
        proposal.x = x;
        proposal.x_onset = x_onset;
        proposal.chord = chord;
        proposal.chord_onset = chord_onset;
        proposal.leaf = leaf;
        proposal.leafpa = leafpa;

        vector<bool> mergeable = vector<bool>(chord.size(),false);
        find_mergeable_chord(tree.get<picojson::object>(),mergeable);

        vector<double> p(N);
        int sum = 0;
        for(int i=0;i<N;i++){
            if(mergeable[i]){
                p[i] = 1.0;
                sum += 1;
            }
        }
        if(sum==0){
            return;
        }
        int n = discrete_sampling(p);
        double model_trans = log(1.0/(double)sum);

        sum = 0;
        for(int i=0;i<N;i++){
            if(i!=n and i!=n+1 and x[i].size()>1){
                sum += 1;
            }
        }
        double model_rev_trans = log(1.0/(double)(sum+1));
        int d = x_onset[n+1][x[n+1].size()-1]-x_onset[n][0]-1;
        model_rev_trans += log(1.0/(double)d);
        model_rev_trans += trans[leafpa[n]][leaf[n]][leaf[n+1]];
        model_rev_trans += out[leaf[n]][chord[n]]+out[leaf[n+1]][chord[n+1]];

        proposal.chord[n] = discrete_sampling_log(out[leafpa[n]]);
        model_trans += out[leafpa[n]][chord[n]];

        proposal.x[n].insert(proposal.x[n].end(),x[n+1].begin(),x[n+1].end());
        proposal.x_onset[n].insert(proposal.x_onset[n].end(),x_onset[n+1].begin(),x_onset[n+1].end());
        proposal.leaf[n] = leafpa[n];
        //leafpa[n] = ?
        proposal.x.erase(proposal.x.begin()+n+1,proposal.x.begin()+n+2);
        proposal.x_onset.erase(proposal.x_onset.begin()+n+1,proposal.x_onset.begin()+n+2);
        proposal.chord.erase(proposal.chord.begin()+n+1,proposal.chord.begin()+n+2);
        proposal.chord_onset.erase(proposal.chord_onset.begin()+n+1,proposal.chord_onset.begin()+n+2);
        proposal.leaf.erase(proposal.leaf.begin()+n+1,proposal.leaf.begin()+n+2);
        proposal.leafpa.erase(proposal.leafpa.begin()+n+1,proposal.leafpa.begin()+n+2);

        /*for(int i=0;i<x.size();i++){
            for(int j=0;j<x[i].size();j++){
                cout << x[i][j] << " ";
            }
            cout << endl;
        }
        cout << "->" << endl;
        proposal.print_x();*/

        //p(s)
        double current_like = emit[leafpa[n]][0]+trans[leafpa[n]][leaf[n]][leaf[n+1]];
        current_like += emit[leaf[n]][1]+out[leaf[n]][chord[n]]+emit[leaf[n+1]][1]+out[leaf[n+1]][chord[n+1]];
        double melody_current;
        if(n==0){
            melody_current = pitch_first[chord[n]][x[n][0]%12];
        }else{
            melody_current = pitch_trans[chord[n]][x[n-1][x[n-1].size()-1]%12][x[n][0]%12];
        }
        melody_current += melodylike(chord[n],x[n]);
        melody_current += pitch_trans[chord[n+1]][x[n][x[n].size()-1]%12][x[n+1][0]%12];
        melody_current += melodylike(chord[n+1],x[n+1]);
        current_like += melody_current;
        double rhythm_current = two_onset_to_chord_onset_trans(chord_onset[n],chord_onset[n+1]);
        if(n==N-2){
            rhythm_current += two_onset_to_chord_onset_trans(chord_onset[n+1],8*NOTE_RESOLUTION);
        }else{
            rhythm_current += two_onset_to_chord_onset_trans(chord_onset[n+1],chord_onset[n+2]);
        }
        current_like += rhythm_current;

        //p(s*)
        double proposal_like = emit[proposal.leaf[n]][1]+out[proposal.leaf[n]][proposal.chord[n]];
        double melody_proposal;
        if(n==0){
            melody_proposal = pitch_first[proposal.chord[n]][proposal.x[n][0]%12];
        }else{
            melody_proposal = pitch_trans[proposal.chord[n]][proposal.x[n-1][proposal.x[n-1].size()-1]%12][proposal.x[n][0]%12];
        }
        melody_proposal += melodylike(proposal.chord[n],proposal.x[n]);
        proposal_like += melody_proposal;
        double rhythm_proposal;
        if(n==N-2){
            rhythm_proposal = two_onset_to_chord_onset_trans(proposal.chord_onset[n],8*NOTE_RESOLUTION);
        }else{
            rhythm_proposal = two_onset_to_chord_onset_trans(proposal.chord_onset[n],proposal.chord_onset[n+1]);
        }
        proposal_like += rhythm_proposal;

        if(rhythm_proposal > rhythm_current){
            merge_rhythm_up += 1;
        }
        if(melody_proposal > melody_current){
            merge_melody_up += 1;
        }
        if(emit[leafpa[n]][0]+trans[leafpa[n]][leaf[n]][leaf[n+1]]
            +emit[leaf[n]][1]+out[leaf[n]][chord[n]]+emit[leaf[n+1]][1]+out[leaf[n+1]][chord[n+1]] <
            emit[proposal.leaf[n]][1]+out[proposal.leaf[n]][proposal.chord[n]]){
            merge_tree_up += 1;
        }
        double acceptance = min(1.0,exp(proposal_like+model_rev_trans-current_like-model_trans));
        if(mh_accept(acceptance)){
            N--;
            likelihood += proposal_like - current_like;
            prev_merge_like = likelihood;
            x = proposal.x;
            x_onset = proposal.x_onset;
            chord = proposal.chord;
            chord_onset = proposal.chord_onset;
            leaf = proposal.leaf;
            leafpa = proposal.leafpa;
            merge_accept+=1;
            prev_opr = 3;
            oppr[0] = 0.4;
            oppr[2] = 0.0;
            oppr[3] = 0.0;
            convert_json(n,"merge");
        }
        refine_5best(best);
        if(likelihood > max_likelihood){
            best_tree = tree;
            max_likelihood = likelihood;
            argmax_T = T;
        }
    }
    double two_onset_to_chord_onset_trans(int start, int end){
        int d = end/NOTE_RESOLUTION - start/NOTE_RESOLUTION;
        return chord_onset_trans[start%NOTE_RESOLUTION][d*NOTE_RESOLUTION+end%NOTE_RESOLUTION];
    }
    int mh_accept(double acceptance){
        int accept;
        vector<double> dice(2);
        dice[0] = acceptance;
        dice[1] = 1.0-acceptance;
        int yn = discrete_sampling(dice);
        if(yn==0){
            accept = 1;
        }else{
            accept = 0;
        }
        return accept;
    }
    void refine_5best(vector<State> &best){
        for(int i=0;i<5;i++){
            if(likelihood > best[i].likelihood){
                if(i==0 || (i>0 && likelihood < best[i-1].likelihood)){
                    for(int j=4;j>i;j--){
                        assign_state(best[j-1],best[j]);
                    }
                    best[i].x = x;
                    best[i].x_onset = x_onset;
                    best[i].chord = chord;
                    best[i].chord_onset = chord_onset;
                    best[i].leaf = leaf;
                    best[i].leafpa = leafpa;
                    best[i].likelihood = likelihood;
                    break;
                }
            }
        }
    }
    void assign_state(State &src, State &dist){
        dist.x = src.x;
        dist.x_onset = src.x_onset;
        dist.chord = src.chord;
        dist.chord_onset = src.chord_onset;
        dist.leaf = src.leaf;
        dist.leafpa = src.leaf;
        dist.likelihood = src.likelihood;
    }
    void convert_json(int chordid, string op){
        picojson::object &tree_elem = tree.get<picojson::object>();
        if(op=="split"){
            split_tree_json(tree_elem,chordid);
        }else{
            string json_txt;
            merge_tree_json(tree_elem,json_txt,chordid);
            stringstream ss;
            ss << json_txt;
            ss >> tree;
        }
        return;
    }
    void split_tree_json(picojson::object &tree, int chordid){
        if(tree["left"].is<picojson::object>()){
            split_tree_json(tree["left"].get<picojson::object>(),chordid);
        }else{
            int node = (int)tree["ntl"].get<double>();
            int idx = (int)tree["left"].get<double>();
            if(idx==chordid){
                stringstream aa,bb,cc,dd;
                aa<<idx,bb<<idx+1,cc<<leaf[idx],dd<<leaf[idx+1];
                string substitute = "{\"left\":"+aa.str()+",\"right\":"+bb.str()+",\"ntl\":"+cc.str()+",\"ntr\":"+dd.str()+"}";
                picojson::value temp;
                stringstream ss;
                ss << substitute;
                ss >> temp;
                tree["left"] = temp;
            }else if(idx>chordid){ //add index 1
                tree["left"] = (picojson::value)((double)(idx+1));
            }
        }
        if(tree["right"].is<picojson::object>()){
            split_tree_json(tree["right"].get<picojson::object>(),chordid);
        }else{
            int node = (int)tree["ntr"].get<double>();
            int idx = (int)tree["right"].get<double>();
            if(idx==chordid){
                stringstream aa,bb,cc,dd;
                aa<<idx,bb<<idx+1,cc<<leaf[idx],dd<<leaf[idx+1];
                string substitute = "{\"left\":"+aa.str()+",\"right\":"+bb.str()+",\"ntl\":"+cc.str()+",\"ntr\":"+dd.str()+"}";
                picojson::value temp;
                stringstream ss;
                ss << substitute;
                ss >> temp;
                tree["right"] = temp;
            }else if(idx>chordid){ //add index 1
                tree["right"] = (picojson::value)((double)(idx+1));
            }
        }
    }
    void merge_tree_json(picojson::object &tree, string &json, int chordid){
        stringstream ntl,ntr;
        ntl << tree["ntl"].get<double>();
        ntr << tree["ntr"].get<double>();
        json += "{\"ntl\":"+ntl.str()+",\"left\":";
        if(tree["left"].is<picojson::object>()){
            picojson::object left = tree["left"].get<picojson::object>();
            if(!left["left"].is<picojson::object>() and !left["right"].is<picojson::object>() and left["left"].get<double>()==chordid){
                stringstream ii;
                ii << chordid;
                json += ii.str();
            }else{
                merge_tree_json(tree["left"].get<picojson::object>(),json,chordid);
            }
        }else{
            int idx = (int)tree["left"].get<double>();
            if(idx>chordid+1){ //subs index 1
                stringstream ss;
                ss << idx-1;
                json += ss.str();
            }else{
                stringstream ss;
                ss << idx;
                json += ss.str();
            }
        }
        json += ",\"ntr\":"+ntr.str()+",\"right\":";
        if(tree["right"].is<picojson::object>()){
            picojson::object right = tree["right"].get<picojson::object>();
            if(!right["left"].is<picojson::object>() and !right["right"].is<picojson::object>() and right["left"].get<double>()==chordid){
                stringstream ii;
                ii << chordid;
                json += ii.str();
            }else{
                merge_tree_json(tree["right"].get<picojson::object>(),json,chordid);
            }
        }else{
            int idx = (int)tree["right"].get<double>();
            if(idx>chordid+1){
                stringstream ss;
                ss << idx-1;
                json += ss.str();
            }else{
                stringstream ss;
                ss << idx;
                json += ss.str();
            }
        }
        json += "}";
    }
    void find_mergeable_chord(picojson::object &tree, vector<bool> &mergeable){
    	bool bl = true;
    	if(tree["left"].is<picojson::object>()){
    		find_mergeable_chord(tree["left"].get<picojson::object>(),mergeable);
    		bl = false;
    	}
        if(tree["right"].is<picojson::object>()){
        	find_mergeable_chord(tree["right"].get<picojson::object>(),mergeable);
        	bl = false;
        }
        if(bl){
        	int idx = tree["left"].get<double>();
        	assert(tree["left"].get<double>() + 1 == tree["right"].get<double>());
        	mergeable[idx] = true;
        }
    }
    void check_leaf_num(picojson::object &tree, int &leafnum){
        if(tree["left"].is<picojson::object>()){
            check_leaf_num(tree["left"].get<picojson::object>(),leafnum);
        }else{
            leafnum += 1;
        }
        if(tree["right"].is<picojson::object>()){
            check_leaf_num(tree["right"].get<picojson::object>(),leafnum);
        }else{
            leafnum += 1;
        }
    }
    vector<State> harmonize(int max_cycle, string viterbi_or_sampling, picojson::value &ret_tree){

        chord.resize(N);
        chord_onset.resize(N);
        leaf.resize(N);
        leafpa.resize(N);

        //initialize chords & their onset
        init_chord();

        State state_init;
        state_init.likelihood = -(numeric_limits<double>::max());
        vector<State> best5(5,state_init);
        picojson::value best_tree;

        vector<vector<vector<double> > > delta(Z, vector<vector<double> >(NMAX, vector<double>(NMAX))); //inside probability
        vector<vector<vector<double> > > cbeta(Z, vector<vector<double> >(NMAX, vector<double>(K)));
        vector<vector<vector<int> > > argmax_B(Z, vector<vector<int> >(NMAX, vector<int>(NMAX)));
        vector<vector<vector<int> > > argmax_C(Z, vector<vector<int> >(NMAX, vector<int>(NMAX)));
        vector<vector<vector<int> > > argmax_j(Z, vector<vector<int> >(NMAX, vector<int>(NMAX)));
        vector<vector<int> > argmax_c(Z, vector<int>(NMAX));

        max_likelihood = -(numeric_limits<double>::max());

        vector<double> oppr{0.4,0.4,0.1,0.1};

        for(int T=0;T<max_cycle;T++){
            //cout << "T: " << T << endl;
            int opr = discrete_sampling(oppr);
            if(T==0){
                opr = 0;
            }
            if(opr==0){
                //cout << "optimizing the chord symbols." << endl;
                if(viterbi_or_sampling=="vtb")
                    optimize_chord_symbols(best_tree,T,best5,oppr,delta,argmax_B,argmax_C,argmax_j,argmax_c);
                if(viterbi_or_sampling=="smpl")
                    resample_chord_symbols(best_tree,T,best5,oppr,delta,cbeta);
            }else if(opr==1){
                //cout << "resampling the chord rhythms." << endl;
                rhythm_count+=1;
                resample_chord_rhythms(best_tree,T,best5,oppr,delta,argmax_B,argmax_C,argmax_j,argmax_c);
            }else if(opr==2){
                //cout << "splitting a chord" << endl;
                split_count+=1;
                split_a_chord(best_tree,T,best5,oppr,delta,argmax_B,argmax_C,argmax_j,argmax_c);
            }else if(opr==3){
                //cout << "merging the chord." << endl;
                merge_count+=1;
                merge_two_chords(best_tree,T,best5,oppr,delta,argmax_B,argmax_C,argmax_j,argmax_c);
            }
            assert(N==x.size() and N==x_onset.size() and N==chord.size() and N==chord_onset.size() and N==leaf.size() and N==leafpa.size());
            int leafn = 0;
            check_leaf_num(tree.get<picojson::object>(),leafn);
            assert(leafn==chord.size());
            /*cout << "currentlike:" << likelihood << endl;
            for(int i=0;i<5;i++){
                cout << "best" << i << ": " << best5[i].likelihood << endl;
            }*/
        }
        ret_tree = best_tree;
        return best5;
    }
    void calc_stats(
        vector<State> &best5,
        vector<int> &chord_groundtruth,
        double &reciprocal_rank_event_sum,
        double &reciprocal_rank_note_sum,
        int &correct_event_sum,
        int &correct_note_sum,
        double &levenshtein_distance_sum,
        double &levenshtein_distance_root_sum,
        double &levenshtein_distance_allnote_sum,
        double &levenshtein_distance_allnote_root_sum,
        int &all_event_sum,
        int &all_note_sum)
    {

        //serialize best5[k]
        vector<vector<int> > best5_serial(5);
        for(int i=0;i<5;i++){
            for(int j=0;j<best5[i].x.size();j++){
                for(int k=0;k<best5[i].x[j].size();k++){
                    best5_serial[i].push_back(best5[i].chord[j]);
                }
            }
            assert(best5_serial[i].size()==chord_groundtruth.size() || best5[i].likelihood < -10000);
        }
        //count up raciprocal_rank and correct_note
        for(int i=0;i<best5_serial[0].size();i++){
            int j;
            for(j=0;j<5;j++){
                if(best5[j].likelihood<-10000){
                    continue;
                }
                //cout << best5_serial[j][i] << " vs " << chord_groundtruth[i] << endl;
                if(best5_serial[j][i]==chord_groundtruth[i]){
                    break;
                }
            }
            if(j<5){
                reciprocal_rank_event_sum += 1.0/(j+1);
            }
            if(j==0){
                correct_event_sum += 1.0;
            }
        }
        all_event_sum += chord_groundtruth.size();

        levenshtein_distance_sum += levenshtein(best5_serial[0],chord_groundtruth,0);
        levenshtein_distance_root_sum += levenshtein(best5_serial[0],chord_groundtruth,1);

        //16thwize
        vector<int> x_onset_serial;
        for(int i=0;i<x_onset.size();i++){
            for(int j=0;j<x_onset[i].size();j++){
                x_onset_serial.push_back(x_onset[i][j]);
            }
        }
        vector<vector<int> > predict_note(5);
        vector<int> groundtruth_note;
        for(int k=0;k<5;k++){
            for(int i=0;i<best5_serial[k].size();i++){
                int length;
                if(i==best5_serial[k].size()-1){
                    if(x_onset_serial[i]>=16*7){
                        length = 16*8-x_onset_serial[i];
                    }else{
                        length = 16*7-x_onset_serial[i];
                    }
                    assert(length>0);
                }else{
                    length = x_onset_serial[i+1]-x_onset_serial[i];
                }
                for(int j=0;j<length;j++){
                    predict_note[k].push_back(best5_serial[k][i]);
                    if(k==0){
                        groundtruth_note.push_back(chord_groundtruth[i]);
                    }
                }
            }
            assert(best5[k].likelihood<-10000 or predict_note[k].size()==groundtruth_note.size());
        }
        all_note_sum += groundtruth_note.size();
        for(int i=0;i<predict_note[0].size();i++){
            int j;
            for(j=0;j<5;j++){
                if(best5[j].likelihood<-10000){
                    continue;
                }
                assert(predict_note[j].size() == groundtruth_note.size());
                if(predict_note[j][i]==groundtruth_note[i]){
                    break;
                }
            }
            if(j<5){
                reciprocal_rank_note_sum += 1.0/(j+1);
            }
            if(j==0){
                correct_note_sum += 1.0;
            }
        }
        levenshtein_distance_allnote_sum += levenshtein(predict_note[0],groundtruth_note,0);
        levenshtein_distance_allnote_root_sum += levenshtein(predict_note[0],groundtruth_note,1);
        return;
    }
    double levenshtein(vector<int> seq1, vector<int> seq2, int cost_no){
        int dim1 = seq1.size();
        int dim2 = seq2.size();
        vector<vector<int> > dp(dim1, vector<int>(dim2,0));
        for(int i=0;i<dim1;i++){
            dp[i][0] = i;
        }
        for(int j=0;j<dim2;j++){
            dp[0][j] = j;
        }
        for(int i=1;i<dim1;i++){
            for(int j=1;j<dim2;j++){
                double cost;
                if(cost_no==0){
                    cost = chord_change_cost(seq1[i-1],seq2[j-1]);
                }else{
                    cost = chord_change_cost_root(seq1[i-1],seq2[j-1]);
                }
                double temp = std::min(dp[i-1][j]+1,dp[i][j-1]+1);
                dp[i][j] = std::min(temp,dp[i-1][j-1]+cost);
            }
        }
        return dp[dim1-1][dim2-1];
    }
    double chord_change_cost(int c1, int c2){
        vector<int> k1 = kouseion(c1);
        vector<int> k2 = kouseion(c2);
        int count = 0;
        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                if(k1[i]==k2[j]){
                    count += 1;
                }
            }
        }
        double cost;
        if(count==0 or count==1){
            cost = 1.0;
        }else if(count==2){
            cost = 1.0;
        }else if(count==3){
            cost = 0.0;
        }else{
            assert(false);
        }
        return cost;
    }
    double chord_change_cost_root(int c1, int c2){
        double cost;
        if(c1/2==c2/2){
            cost = 0.0;
        }else{
            cost = 1.0;
        }
        return cost;
    }
    vector<int> kouseion(int chordno){
        vector<int> notes(3);
        int root = chordno/2;
        int mod = chordno%2;
        notes[0] = root;
        notes[2] = (root+7)%12;
        if(mod==0){
            notes[1] = (root+4)%12;
        }else{
            notes[1] = (root+3)%12;
        }
        return notes;
    }
    void print_tree(picojson::object &tree, vector<int> chord, ofstream &ofs){
    	ofs << " ( ";
    	if(tree["left"].is<picojson::object>()){
    		ofs << "S" << tree["ntl"];
            print_tree(tree["left"].get<picojson::object>(),chord,ofs);
            //ofs << " ) ";
        }else{
        	int idx = (int)tree["left"].get<double>();
        	string chordlabel = num_to_tone(chord[idx]/2)+num_to_color(chord[idx]%2);
        	ofs << "S" << (int)tree["ntl"].get<double>() << " ( " << chordlabel << " )";
        }
        ofs << " ";
        if(tree["right"].is<picojson::object>()){
        	ofs << "S" << tree["ntr"];
        	print_tree(tree["right"].get<picojson::object>(),chord,ofs);
        	//ofs << " ) ";
        }else{
        	int idx = (int)tree["right"].get<double>();
        	string chordlabel = num_to_tone(chord[idx]/2)+num_to_color(chord[idx]%2);
        	ofs << "S" << (int)tree["ntr"].get<double>() << " ( " << chordlabel << " )";
        }
        ofs << " ) ";
    }

    void remove_other_nochord(State& state) {
      for (int i = 0; i < state.chord.size(); i++) {
        if (0 <= state.chord[i] && state.chord[i] < 24) { continue; }
        // chord == 0 --> C major
        state.chord[i] = ((i == 0) ? 0 : state.chord[i-1]);
      }
    }
    void remove_other_nochord(std::vector<State>& states) {
      for (State& s : states) { remove_other_nochord(s); }
    }

    void eval(
        string paramdir, string tryy, string cycle,
        int max_cycle, string viterbi_or_sampling,
        string in_fname,
        string out_chord_fname,
        string out_tree_fname)
    {

        NMAX=32;

        if(viterbi_or_sampling != "vtb" && viterbi_or_sampling != "smpl"){
            return;
        }

        //input learned parameters
        input_params(paramdir, Z, tryy, cycle);

        N = input_melody(in_fname);

        picojson::value tree;
        vector<State> best5 = harmonize(max_cycle, viterbi_or_sampling, tree);

        assert(best5[0].likelihood == max_likelihood);

        remove_other_nochord(best5);

        {// save chord
            ofstream ofs(out_chord_fname.c_str());
            if (!ofs.good()) {
              cerr << "falied to open out_chord_fname" << endl;
              exit(EXIT_FAILURE);
            }
            ofs << "TUNEID: " << in_fname << endl;
            ofs << "symb: ";
            for(int i = 0; i < best5[0].chord.size(); i++){
                int c = best5[0].chord[i];
                ofs << num_to_tone(c/2) << num_to_color(c%2) << " ";
            }
            ofs << endl << "onset: ";
            for(int i = 0; i < best5[0].chord_onset.size(); i++){
                ofs << best5[0].chord_onset[i] << " ";
            }
            ofs << endl << endl;
        }

        {// save tree
            ofstream ofs_tree(out_tree_fname.c_str());
            if (!ofs_tree.good()) {
              cerr << "falied to open out_tree_fname" << endl;
              exit(EXIT_FAILURE);
            }
            ofs_tree << "TUNEID: " << in_fname << endl << "S";
            print_tree(tree.get<picojson::object>(),best5[0].chord,ofs_tree);
            ofs_tree << endl;
        }

        /*
        {
            ofstream ofs_eval(out_eval_fname.c_str());
            if (!ofs_eval.good()) {
              cerr << "falied to open out_eval_fname" << endl;
              exit(EXIT_FAILURE);
            }

            int alltunenum = 1;
            double reciprocal_rank_sum = 0.0;
            double reciprocal_rank_note_sum = 0.0;
            int correct_event_num = 0;
            int correct_note_num = 0;
            int all_event_sum = 0;
            int all_note_sum = 0;
            double levenshtein_distance_sum = 0.0;
            double levenshtein_distance_root_sum = 0.0;
            double levenshtein_distance_allnote_sum = 0.0;
            double levenshtein_distance_allnote_root_sum = 0.0;
            int bestNmean=0;
            int bestlikemean=0;

            bestNmean += best5[0].chord.size();
            bestlikemean += best5[0].likelihood;
            calc_stats(
                best5,chord_groundtruth, reciprocal_rank_sum, reciprocal_rank_note_sum,
                correct_event_num, correct_note_num, levenshtein_distance_sum,
                levenshtein_distance_root_sum, levenshtein_distance_allnote_sum,
                levenshtein_distance_allnote_root_sum, all_event_sum,all_note_sum);

            ofs_eval << "bestNmean: " << (double)bestNmean/(double)alltunenum << endl;
            ofs_eval << "bestlikemean: " << bestlikemean/(double)alltunenum << endl;
            ofs_eval << "accuracy_per_event: " << 100*(double)correct_event_num/(double)all_event_sum << endl;
            ofs_eval << "accuracy_per_note: " << 100*(double)correct_note_num/all_note_sum << endl;
            ofs_eval << "MRR_per_event: " << (double)reciprocal_rank_sum/all_event_sum << endl;
            ofs_eval << "MRR_per_note: " << (double)reciprocal_rank_note_sum/all_note_sum << endl;
            ofs_eval << "levenshtein_per_event: " << levenshtein_distance_sum << endl;
            ofs_eval << "levenshtein_root_per_event: " << levenshtein_distance_root_sum << endl;
            ofs_eval << "levenshtein_per_note: " << levenshtein_distance_allnote_sum << endl;
            ofs_eval << "levenshtein_root_per_note: " << levenshtein_distance_allnote_root_sum << endl;
            ofs_eval << "levenshtein_per_measure: " << (double)levenshtein_distance_allnote_sum*16/all_note_sum << endl;
            ofs_eval << "levenshtein_root_per_measure: " << (double)levenshtein_distance_allnote_root_sum*16/all_note_sum << endl;
        }
        */
    }

    double melodylike(int c, vector<int> &x){
        double likelihood = 0;
        for(int i=1;i<x.size();i++){
            likelihood += pitch_trans[c][x[i-1]%12][x[i]%12];
        }
        return likelihood;
    }
};
int main(int argc, char *argv[]){
    //1. in_fname, 2. out_chord_fname, 3. out_tree_fname
    if(argc!=4){
        cerr << "Error in usage!" << endl;
        cerr << "$ ./this in.txt out_chord.txt out_tree.txt" << endl;
        return -1;
    }

    const std::string exepath(argv[0]);
    const std::string exedir(exepath.substr(0, exepath.find_last_of("/")));

    Evaluator evl(/*Z = */18);
    evl.eval(
        /*param_dir = */ exedir + "/../params/SSHMMPCFG",
        /*tryy      = */ "67",
        /*cycle     = */ "332",
        /*iterator  = */ 5000,
        /*viterbi_or_sampling = */ "vtb",   // ("vtb" or "smpl")
        /*in_fname            = */ argv[1],
        /*out_chord_fname     = */ argv[2],
        /*out_tree_fname      = */ argv[3]
    );
}
