*** Complile and run ***

To compile the program, run

./compile.sh

The boost library is necessary for compiling. In compile.sh you need to replace PATH_TO_BOOST to a proper folder location.

To run the example the program,

./harmonize in_melo.txt out_chord.txt out_tree.txt

The three input files are an input melody file, output chord file, and output tree file. The file formats of these files are described below.

*** Data format ***

The input melody must be written in the following form.

2 4 6 7 12 14 16 18 20 22 23 28 30 38 40 42 43 46 48 50 52 55 60 62 64 66 68 70 71 76 78 80 82 84 86 87 92 94 98 100 102 103 106 108 110 112 
72 71 67 69 64 67 69 72 71 67 69 76 76 76 76 74 72 71 68 64 76 74 64 67 69 72 71 67 69 64 67 69 72 71 67 69 76 76 74 72 71 68 64 71 72 71 

The first line represents the onset times of melody notes. The second line represents the pitches in MIDI number (60 = A4).

The output chord file looks as follows.

TUNEID: ../data/in_example.txt
symb: F Em Em E Em G A 
onset: 0 4 16 48 52 96 100 

The second line represents the chord symbols and the third line represents their onset times.

In the output tree file, the parsed tree is shown as an S-expression as follows.

TUNEID: ../data/in_example.txt
S ( S6 ( S14 ( S1 ( F ) S3 ( Em ) )  S14 ( S1 ( Em ) S3 ( E ) )  )  S6 ( S12 ( S3 ( Em ) S3 ( G ) )  S2 ( A ) )  ) 

