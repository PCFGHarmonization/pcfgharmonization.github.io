#ifndef DEBUG_HPP
#define DEBUG_HPP

#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

template <typename T>
void print_1d(vector<T> &vec){
	for(int i=0;i<vec.size();i++){
		cout << vec[i] << " ";
	}
	cout << endl;
}
template <typename T>
void print_2d(vector<vector<T> > &vec){
	for(int i=0;i<vec.size();i++){
		for(int j=0;j<vec[i].size();j++){
			cout << vec[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;
}
template <typename T>
void print_3d(vector<vector<vector<T> > > &vec){
	for(int i=0;i<vec.size();i++){
		for(int j=0;j<vec[i].size();j++){
			for(int k=0;k<vec[i][j].size();k++){
				cout << vec[i][j][k] << " ";
			}
			cout << endl;
		}
		cout << "--" << endl;
	}
	cout << endl;
}
template <typename T>
bool equal_1d(vector<T> &vec1, vector<T> &vec2){
	if(vec1.size()!=vec2.size()){
		return false;
	}else{
		for(int i=0;i<vec1.size();i++){
			if(vec1[i].size()!=vec2[i].size()){
				return false;
			}
		}
		return true;
	}
}
template <typename T>
bool equal_2d(vector<vector<T> > &vec1, vector<vector<T> > &vec2){
	if(vec1.size()!=vec2.size()){
		return false;
	}else{
		for(int i=0;i<vec1.size();i++){
			if(vec1[i].size()!=vec2[i].size()){
				return false;
			}else{
				for(int j=0;j<vec1[i].size();j++){
					if(vec1[i][j]!=vec2[i][j]){
						return false;
					}
				}
			}
		}
		return true;
	}
}

#endif // DEBUG_HPP