#ifndef RANDOM_HPP
#define RANDOM_HPP

#include <iostream>
#include <cmath>
#include <vector>
#include <random>
#include "math.hpp"

using namespace std;

int discrete_sampling(vector<double> &param){
    boost::random::discrete_distribution<> discrete_dist(param);
    static boost::random::mt19937 gen;
    struct timeval tv;
    gettimeofday(&tv, NULL);
    gen.seed(tv.tv_sec * 1000000 + tv.tv_usec);
    return discrete_dist(gen);
}
int discrete_sampling_log(vector<double> &param){
    int dim = param.size();
    vector<double> param_linear(dim);
    for(int i=0;i<dim;i++){
        param_linear[i] = exp(param[i]);
    }
    boost::random::discrete_distribution<> discrete_dist(param_linear);
    static boost::random::mt19937 gen;
    struct timeval tv;
    gettimeofday(&tv, NULL);
    gen.seed(tv.tv_sec * 1000000 + tv.tv_usec);
    return discrete_dist(gen);
}
vector<int> discrete_sampling_2d_log(vector<vector<double> > &param){
    
    int dim1 = param.size();
    int dim2 = param[0].size();
    
    vector<double> integ(dim1*dim2);
    
    double ck=0.0;
    for(int i=0;i<dim1;i++){
        for(int j=0;j<dim2;j++){
            integ[i*dim2+j] = exp(param[i][j]);
            ck += integ[i*dim2+j];
        }
    }
    boost::random::discrete_distribution<> discrete_dist(integ);
    static boost::random::mt19937 gen;
    struct timeval tv;
    gettimeofday(&tv, NULL);
    gen.seed(tv.tv_sec * 1000000 + tv.tv_usec);
    
    int d = discrete_dist(gen);
    
    int d1 = d/(dim2);
    int d2 = d-d1*dim2;
    
    vector<int> v(2);
    v[0] = d1;
    v[1] = d2;
    return v;
}
vector<int> discrete_sampling_3d(vector<vector<vector<double> > > &param){
    
    int dim1 = param.size();
    int dim2 = param[0].size();
    int dim3 = param[0][0].size();
    
    vector<double> integ(dim1*dim2*dim3);
    
    for(int i=0;i<dim1;i++){
        for(int j=0;j<dim2;j++){
            for(int k=0;k<dim3;k++){
                integ[i*dim2*dim3+j*dim3+k] = param[i][j][k];
            }
        }
    }
    boost::random::discrete_distribution<> discrete_dist(integ);
    static boost::random::mt19937 gen;
    struct timeval tv;
    gettimeofday(&tv, NULL);
    gen.seed(tv.tv_sec * 1000000 + tv.tv_usec);
    
    int d = discrete_dist(gen);
    
    int d1 = d/(dim2*dim3);
    int d2 = (d-d1*dim2*dim3)/dim3;
    int d3 = d-d1*dim2*dim3-d2*dim3;
    
    vector<int> v(3);
    v[0] = d1;
    v[1] = d2;
    v[2] = d3;
    return v;
}
double gamma_rand(double shape){
    if(shape==0){
        return 0.0;
    }
    boost::random::gamma_distribution<> dist(shape, 1.0);
    static boost::random::mt19937 gen;
    struct timeval tv;
    gettimeofday(&tv, NULL);
    gen.seed(tv.tv_sec * 1000000 + tv.tv_usec);
    return dist(gen);
}
vector<double> dirichlet_distribution(vector<double> &alpha){
    
    int dim = alpha.size();
    vector<double> theta(dim);
    
    for(int d=0;d<dim;d++){
        theta[d] = gamma_rand(alpha[d]);
    }
    for(int d=0;d<dim;d++){
        theta[d] = max(numeric_limits<double>::min(),theta[d]);
    }
    theta = normalize(theta);
    for(int d=0;d<dim;d++){
        theta[d] = max(numeric_limits<double>::min(), theta[d]);
    }
    return theta;
}
vector<vector<double> > dirichlet_distribution_2d(vector<vector<double> > &alpha){
    
    int dim1 = alpha.size();
    int dim2 = alpha[0].size();
    
    vector<vector<double> > theta(dim1, vector<double>(dim2));
    
    for(int i=0;i<dim1;i++){
        for(int j=0;j<dim2;j++){
            theta[i][j] = gamma_rand(alpha[i][j]);
        }
    }
    for(int i=0;i<dim1;i++){
        for(int j=0;j<dim2;j++){
            theta[i][j] = max(numeric_limits<double>::min(),theta[i][j]);
        }
    }
    theta = normalize_2d(theta);
    for(int i=0;i<dim1;i++){
        for(int j=0;j<dim2;j++){
            theta[i][j] = max(numeric_limits<double>::min(),theta[i][j]);
        }
    }
    return theta;
}
double uniform_rand(double min, double max){
    boost::random::uniform_real_distribution<double> dist(min,max);
    static boost::random::mt19937 gen;
    struct timeval tv;
    gettimeofday(&tv, NULL);
    gen.seed(tv.tv_sec * 1000000 + tv.tv_usec);
    return dist(gen);
}
int uniform_rand_int(int min, double max){
    return (int)uniform_rand(min,max+0.99);
}
vector<int> generateUniqueRandomIntegers(size_t max, int num)
{
    std::random_device rnd;
    std::mt19937 mt(rnd());
    std::vector<int> v(max+1);
    std::iota(v.begin(), v.end(), 0);
    std::shuffle(v.begin(), v.end(), mt);
    v.erase(v.begin()+num, v.end());
    return v;
}
#endif // RANDOM_HPP