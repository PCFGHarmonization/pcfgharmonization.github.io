#ifndef CHORDNAME_HPP
#define CHORDNAME_HPP

#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

string num_to_tone(int num){
    string str;
    if(num == 0){
        str = "C";
    }else if(num == 1){
        str = "C#";
    }else if(num == 2){
        str = "D";
    }else if(num == 3){
        str = "Eb";
    }else if(num == 4){
        str = "E";
    }else if(num == 5){
        str = "F";
    }else if(num == 6){
        str = "F#";
    }else if(num == 7){
        str = "G";
    }else if(num == 8){
        str = "Ab";
    }else if(num == 9){
        str = "A";
    }else if(num == 10){
        str = "Bb";
    }else if(num == 11){
        str = "B";
    }
    return str;
}
string num_to_color(int num){

    string str;
    if(num == 0){
        str = "";
    }else if(num == 1){
        str = "m";
    }
    return str;
}
string num_to_chord(int num){
    string chordname;
    if(num==24){
        chordname = "other";
    }else if(num==25){
        chordname = "NC";
    }else{
        chordname = num_to_tone(num/2)+num_to_color(num%2);
    }
    return chordname;
}

#endif // CHORDNAME_HPP