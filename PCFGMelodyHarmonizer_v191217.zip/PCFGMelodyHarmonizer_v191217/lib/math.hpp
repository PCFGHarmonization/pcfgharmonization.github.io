#ifndef MATH_HPP
#define MATH_HPP

#include <iostream>
#include <cmath>
#include <vector>
#include <eigen3/unsupported/Eigen/CXX11/Tensor>

using namespace std;

double log_sum(double x, double y){
    if(x - y > 20){
        return x;
    }else if(y - x > 20){
        return y;
    }else{
        double ma = max(x,y);
        double mi = min(x,y);
        
        return ma + log(1 + std::exp(mi-ma));
    }
}
double log_sum_vec(Eigen::VectorXd &vec, int dim){
    double max = -(numeric_limits<double>::max());
    for(int d=0;d<dim;d++){
        if(vec[d]>max){
            max = vec(d);
        }
    }
    double sum = 0.0;
    for(int d=0;d<dim;d++){
        sum += exp(vec(d)-max);
    }
    return max + log(sum);
}
template <typename T>
void log_convert_1d(vector<T> &vec){
    for(int i=0;i<vec.size();i++){
        vec[i] = log(vec[i]);
    }
}
template <typename T>
void log_convert_2d(vector<vector<T> > &vec){
    for(int i=0;i<vec.size();i++){
        for(int j=0;j<vec[i].size();j++){
            vec[i][j] = log(vec[i][j]);
        }
    }
}
template <typename T>
void log_convert_3d(vector<vector<vector<T> > > &vec){
    for(int i=0;i<vec.size();i++){
        for(int j=0;j<vec[i].size();j++){
            for(int k=0;k<vec[i][j].size();k++){
                vec[i][j][k] = log(vec[i][j][k]);
            }
        }
    }
}
vector<double> normalize(vector<double> &vec){
    int dim = vec.size();
    double sum = 0.0;
    for(int d=0;d<dim;d++){
        sum += vec[d];
    }
    for(int d=0;d<dim;d++){
        vec[d] = vec[d] / sum;
    }
    return vec;
}
vector<vector<double> > normalize_2d(vector<vector<double> > &vec){
    int dim1 = vec.size();
    int dim2 = vec[0].size();
    double sum = 0.0;
    for(int i=0;i<dim1;i++){
        for(int j=0;j<dim2;j++){
            sum += vec[i][j];
        }
    }
    for(int i=0;i<dim1;i++){
        for(int j=0;j<dim2;j++){
            vec[i][j] = vec[i][j] /sum;
        }
    }
    return vec;
}
vector<vector<double> > normalize_2d_log(vector<vector<double> > &vec){
    int dim1 = vec.size();
    int dim2 = vec[0].size();
    double sum = -(numeric_limits<double>::max());
    for(int i=0;i<dim1;i++){
        for(int j=0;j<dim2;j++){
            sum = log_sum(sum,vec[i][j]);
        }
    }
    for(int i=0;i<dim1;i++){
        for(int j=0;j<dim2;j++){
            vec[i][j] -= sum;
        }
    }
    return vec;
}
vector<int> sorted_idx(vector<double> vec){ //not call by reference
    int dim = vec.size();
    vector<int> idx(dim);
    for(int i=0;i<dim;i++){
        idx[i] = i;
    }
    for(int i=0;i<dim-1;i++){
        for(int j=dim-1;j>i;j--){
            if(vec[j]>vec[j-1]){
                double t=vec[j];
                vec[j]=vec[j-1];
                vec[j-1]=t;
                int s=idx[j];
                idx[j]=idx[j-1];
                idx[j-1]=s;
            }
        }
    }
    return idx;
}
vector<int> sorted_2d_idx(vector<vector<double> > vec){
    
    int dim1 = vec.size();
    int dim2 = vec[0].size();
    int dim = dim1*dim2;
    
    vector<int> idx(dim);
    vector<double> _vec(dim);
    for(int i=0;i<dim1;i++){
        for(int j=0;j<dim2;j++){
            idx[i*dim2+j] = i*dim2+j;
            _vec[i*dim2+j] = vec[i][j];
        }
    }
    for(int i=0;i<dim-1;i++){
        for(int j=dim-1;j>i;j--){
            if(_vec[j]>_vec[j-1]){
                double t=_vec[j];
                _vec[j]=_vec[j-1];
                _vec[j-1]=t;
                int s=idx[j];
                idx[j]=idx[j-1];
                idx[j-1]=s;
            }
        }
    }
    return idx;
}

#endif // MATH_HPP