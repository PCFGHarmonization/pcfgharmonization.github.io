#ifndef SERIALIZATION_DATA_STRUCT_HPP
#define SERIALIZATION_DATA_STRUCT_HPP

#include <iostream>
#include <sstream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <string>
#include <boost/random.hpp>
#include <boost/math/distributions.hpp>
#include <boost/math/special_functions/gamma.hpp>
#include <boost/math/special_functions/digamma.hpp>
#include <boost/archive/xml_oarchive.hpp>
#include <boost/archive/xml_iarchive.hpp>
#include <boost/serialization/serialization.hpp>
#include <boost/serialization/nvp.hpp>
#include <boost/serialization/string.hpp>
#include <boost/serialization/vector.hpp>
#include <sys/types.h>
#include <sys/time.h>
#include <dirent.h>
#include "random.hpp"
#include "math.hpp"
#include "chordname.hpp"

using namespace std;

#define K 26
#define NOTE_RESOLUTION 16 //最小音符単位

class Melody{
public:
    Melody(){}
    vector<vector<int> > pitch;
    vector<vector<int> > note_onset;
    vector<int> chord_answer;
private:
    friend class boost::serialization::access;
    template <class Archive>
    void serialize(Archive& ar, unsigned int version){
        ar & boost::serialization::make_nvp("pitch",pitch);
        ar & boost::serialization::make_nvp("note_onset",note_onset);
        ar & boost::serialization::make_nvp("chord_answer",chord_answer);
    }
};

class PcfgParams{
public:
    int Z;
    vector<vector<vector<double> > > trans;
    vector<vector<double> > out;
    vector<vector<double> > emit;
    PcfgParams(int _Z){
        Z = _Z;
    }
    void log_convert(){
        for(int A=0;A<Z;A++){
            for(int B=0;B<Z;B++){
                for(int C=0;C<Z;C++){
                    trans[A][B][C] = log(trans[A][B][C]);
                }
            }
            for(int a=0;a<K;a++){
                out[A][a] = log(out[A][a]);
            }
            for(int i=0;i<2;i++){
                emit[A][i] = log(emit[A][i]);
            }
        }
    }
private:
    friend class boost::serialization::access;
    template <class Archive>
    void serialize(Archive& ar, unsigned int version){
        ar & boost::serialization::make_nvp("trans",trans);
        ar & boost::serialization::make_nvp("out",out);
        ar & boost::serialization::make_nvp("emit",emit);
    }
};

class RockCorpusParams{
public:
    RockCorpusParams(){}
    vector<vector<double> > chord_onset_pr;
    vector<vector <double> > note_onset_bigram;
    vector<vector<vector <double> > > note_onset_trigram;
    vector<double> chord_notewize_pi;
    vector<vector<double> > chord_notewize_trans;
    vector<vector<double> > pitch_notewize_emit;
    vector<vector <double> > pitch_first;
    vector<vector<vector <double> > > pitch_trans;
    vector<vector <double> > pitch_class_first;
    vector<vector<vector <double> > > pitch_class_trans;
    void log_convert(){
        for(int c=0;c<K;c++){
            for(int i=0;i<12;i++){
                pitch_class_first[c][i] = log(pitch_class_first[c][i]);
                for(int j=0;j<12;j++){
                    pitch_class_trans[c][i][j] = log(pitch_class_trans[c][i][j]);
                }
            }
        }
        for(int i=0;i<NOTE_RESOLUTION;i++){
            for(int j=0;j<NOTE_RESOLUTION*8;j++){
                chord_onset_pr[i][j] = log(chord_onset_pr[i][j]);
            }
        }
    }
    void alpha_product_to_pitch_models(double alpha){
        for(int c=0;c<K;c++){
            for(int i=0;i<12;i++){
                pitch_class_first[c][i] *= alpha;
                for(int j=0;j<12;j++){
                    pitch_class_trans[c][i][j] *= alpha;
                }
            }
        }
    }
private:
    friend class boost::serialization::access;
    template <class Archive>
    void serialize(Archive& ar, unsigned int version){
        ar & boost::serialization::make_nvp("chord_onset_pr",chord_onset_pr);
        ar & boost::serialization::make_nvp("note_onset_bigram",note_onset_bigram);
        ar & boost::serialization::make_nvp("note_onset_trigram",note_onset_trigram);
        ar & boost::serialization::make_nvp("chord_notewize_pi",chord_notewize_pi);
        ar & boost::serialization::make_nvp("chord_notewize_trans",chord_notewize_trans);
        ar & boost::serialization::make_nvp("pitch_notewize_emit",pitch_notewize_emit);
        ar & boost::serialization::make_nvp("pitch_first",pitch_first);
        ar & boost::serialization::make_nvp("pitch_trans",pitch_trans);
        ar & boost::serialization::make_nvp("pitch_class_first",pitch_class_first);
        ar & boost::serialization::make_nvp("pitch_class_trans",pitch_class_trans);
    }
};

class State{
public:
    State(){}
    vector<vector<int> > x;
    vector<vector<int> > x_onset;
    vector<int> chord;
    vector<int> chord_onset;
    vector<int> leaf;
    vector<int> leafpa;
    double likelihood;
    void all_resize(int len){
        x.resize(len);
        x_onset.resize(len);
        chord.resize(len);
        chord_onset.resize(len);
        leaf.resize(len);
        leafpa.resize(len);
    }
    void print_x(){
        for(int i=0;i<x.size();i++){
            for(int j=0;j<x[i].size();j++){
                cout << x[i][j] << " ";
            }
            cout << endl;
        }
    }
    void print_x_onset(){
        for(int i=0;i<x_onset.size();i++){
            for(int j=0;j<x_onset[i].size();j++){
                cout << x_onset[i][j] << " ";
            }
            cout << endl;
        }
    }
};

#endif
